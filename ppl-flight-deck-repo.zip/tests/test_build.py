"""Single source: index.html and demo.html must be exactly what build.py makes from src/app.html."""
import os, sys, importlib.util
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location('build', os.path.join(ROOT, 'build.py')); build = importlib.util.module_from_spec(spec); spec.loader.exec_module(build)
results = []
def check(n, c, d=''): results.append((n, bool(c), str(d)[:200]))
src = open(os.path.join(ROOT, 'src', 'app.html'), encoding='utf-8').read()
idx = open(os.path.join(ROOT, 'index.html'), encoding='utf-8').read()
demo = open(os.path.join(ROOT, 'demo.html'), encoding='utf-8').read()
check('index.html is exactly src/app.html (rebuild after editing the source)', idx == src)
check('demo.html is exactly the demo build of src/app.html', demo == build.build_demo(src))
check('demo uses its own storage key, personal app its own', "const STORE='ppl-flight-deck-demo'" in demo and "const STORE='ppl-flight-deck-v13'" in idx and 'ppl-flight-deck-demo' not in idx.split('const STORE')[1][:40])
check('demo has sync disabled; personal app keeps it', 'let sync={}; /* DEMO: sync disabled */' in demo and 'let sync={};' not in idx)
check('tour only in the demo', 'tour-hole' in demo and 'tour-hole' not in idx and 'id="tourBtn"' in demo and 'tourBtn' not in idx)
check('fictional data only in the demo', 'function demoState()' in demo and 'function demoState()' not in idx)
ok = sum(r[1] for r in results)
print(f'\n{ok}/{len(results)} build tests passed\n')
for n, g, d in results: print(('PASS ' if g else 'FAIL ') + n + ('' if g else f'\n      → {d}'))
sys.exit(0 if ok == len(results) else 1)
