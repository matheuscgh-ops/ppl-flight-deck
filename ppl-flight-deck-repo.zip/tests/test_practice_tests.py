"""Practice tests: tab, dashboard strip, Statistics › Practice tests, blended forecast, volume and plan cadence.
Runs on desktop, laptop, iPad mini and iPhone — personal (index.html) and demo (demo.html)."""
import os, sys
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1'
results = []
def check(n, c, d=''): results.append((n, bool(c), str(d)[:220]))

DEV = [('desktop', dict(viewport={'width': 2000, 'height': 1190})),
       ('laptop', dict(viewport={'width': 1440, 'height': 900})),
       ('iPad mini', dict(viewport={'width': 744, 'height': 1133}, is_mobile=True, has_touch=True, user_agent=UA.replace('iPhone; CPU iPhone OS', 'iPad; CPU OS'))),
       ('phone', dict(viewport={'width': 402, 'height': 874}, is_mobile=True, has_touch=True, user_agent=UA))]

# five scored tests rising ~1 point a day plus one test in progress
SETUP = """(()=>{state.events=[];state.settings={minutes:180,qph:40,testEvery:3,reviewMin:1.5};
  const ev=(n,topic,kind,sc)=>state.events.push({id:uid(),date:addDays(todayISO(),-n),topic,kind,from:null,to:null,score:sc,partial:false,demo:false});
  ev(1,18,'study',70);ev(1,13,'study',88);
  state.tests=[[16,62],[12,66],[8,70],[4,74],[1,78]].map(([n,s])=>({id:uid(),date:addDays(todayISO(),-n),q:60,score:s}));
  state.tests.push({id:'inprog',date:todayISO(),q:60,score:null});
  save();render();})()"""
EMPTY = "(()=>{state.tests=[];save();render();})()"

with sync_playwright() as p:
    b = p.chromium.launch()
    for f in ['index', 'demo']:
        url = 'file://' + os.path.join(ROOT, f + '.html')
        for mode, opts in DEV:
            c = b.new_context(**opts); pg = c.new_page(); errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto(url); pg.wait_for_timeout(450)
            tag = f'{f} · {mode}'; touch = mode in ('phone', 'iPad mini'); tap = pg.tap if touch else pg.click
            W = opts['viewport']['width']; H = opts['viewport']['height']
            ev = pg.evaluate

            # ---------- tabs ----------
            check(f'{tag}: tab order Dashboard / Plan / Tests / Statistics', ev("[...document.querySelectorAll('.tabs button')].map(b=>b.dataset.view).join()") == 'dash,plan,tests,sr')
            check(f'{tag}: tab label "Tests"', pg.inner_text('.tabs button[data-view="tests"]') == 'Tests')
            check(f'{tag}: header tabs still fit the screen', ev('document.documentElement.scrollWidth') == W)

            # ---------- dashboard strip ----------
            pg.evaluate(SETUP); pg.wait_for_timeout(200)
            check(f'{tag}: practice-tests strip is the last panel on the dashboard', ev("document.querySelector('#viewDash > :last-child').id") == 'tsStrip' and pg.is_visible('#tsStrip'))
            check(f'{tag}: strip shows last score 78%', pg.inner_text('#tsLast') == '78%', pg.inner_text('#tsLast'))
            k = pg.inner_text('#tsStripKpis')
            check(f'{tag}: strip shows best 78% and average of last 3 = 74%', '78%' in k and '74%' in k, k)
            check(f'{tag}: strip mini chart has 5 points and 70% / 85% lines', ev("document.querySelectorAll('#tsSpark circle').length") == 5 and ev("document.querySelectorAll('#tsSpark .c70,#tsSpark .c85').length") == 2)
            check(f'{tag}: strip says next practice test in 2 days', 'in 2 d' in pg.inner_text('#tsStripNext'), pg.inner_text('#tsStripNext'))
            if mode == 'desktop':
                check(f'{tag}: dashboard with the strip still fits one screen', ev('document.documentElement.scrollHeight') == H, ev('document.documentElement.scrollHeight'))
                bottom = ev("document.getElementById('tsStrip').getBoundingClientRect().bottom")
                check(f'{tag}: strip fully visible above the fold', bottom <= H, bottom)
                cal = ev("Math.max(...[...document.querySelectorAll('.cell .evs, .cell')].map(c=>c.scrollWidth-c.clientWidth))")
                check(f'{tag}: calendar cells do not overflow sideways', cal <= 1, cal)
            check(f'{tag}: dashboard not wider than the screen', ev('document.documentElement.scrollWidth') == W)

            # ---------- volume card: unchanged layout, +60 per scored test, 0 in progress ----------
            q_week = ev("weeklyVolume(12).at(-1).q")
            q_events = ev("(()=>{const ws=weekStart(todayISO());return state.events.filter(e=>weekStart(e.date)===ws&&e.kind!=='partial').length})()")
            n_tests_week = ev("(()=>{const ws=weekStart(todayISO());return state.tests.filter(x=>x.score!=null&&weekStart(x.date)===ws).length})()")
            ev("state.tests.forEach(x=>x.q=40);save();render()")
            check(f'{tag}: every scored practice test counts 60 questions (even if saved as 40)', ev("weeklyVolume(12).at(-1).q") == q_week)
            ev("state.tests=state.tests.filter(x=>x.score!=null);save();render()")
            check(f'{tag}: a test in progress adds 0 questions', ev("weeklyVolume(12).at(-1).q") == q_week)
            ev("state.tests.push({id:'inprog',date:todayISO(),q:60,score:null});save();render()")
            check(f'{tag}: "This week" number equals the volume series', pg.inner_text('#volWeek').replace(',', '') == str(q_week), (pg.inner_text('#volWeek'), q_week))
            kids = ev("[...document.querySelectorAll('#volCard *[id]')].map(x=>x.id).join()")
            check(f'{tag}: volume card unchanged (same elements, footer "Practice test (best)")', all(k in kids for k in ['volOpen','volWeek','volMini','ptStat','ptBest']) and 'tsStrip' not in kids, kids)
            check(f'{tag}: volume footer still shows the best practice test', pg.inner_text('#ptBest') == '78%', pg.inner_text('#ptBest'))
            tap('#volOpen'); pg.wait_for_timeout(250)
            check(f'{tag}: big volume chart still opens with its range selector', pg.is_visible('#volbg') and ev("document.querySelectorAll('#volRange button').length") == 8)
            pg.click('#volClose'); pg.wait_for_timeout(100)

            # ---------- exam forecast card: same look, blended numbers ----------
            B = ev("(()=>{const B=blended();return {mu:B.mu,pass:B.pass,goal:B.goal,w:B.w,n:B.n,model:B.model,avg:B.testsAvg}})()")
            check(f'{tag}: blended score uses the last 3 tests with weight 3/5', B['n'] == 3 and abs(B['w'] - .6) < 1e-9 and abs(B['avg'] - .74) < 1e-9, B)
            check(f'{tag}: forecast card shows the blended score', pg.inner_text('#fcMiniVal') == f"{round(B['mu']*100)}%", (pg.inner_text('#fcMiniVal'), B))
            sub = pg.inner_text('#fcMiniSub')
            check(f'{tag}: forecast card chances come from the blended score', f"{round(B['pass']*100)}%" in sub and f"{round(B['goal']*100)}%" in sub, sub)
            check(f'{tag}: forecast card keeps its bar with 70% / 85% marks', ev("document.querySelectorAll('#fcMini .fcbar .m70, #fcMini .fcbar .m85').length") == 2)
            tap('#fcMini'); pg.wait_for_timeout(200)
            check(f'{tag}: tapping the forecast card lists 3 topics', pg.is_visible('#fcTopBg') and ev("document.querySelectorAll('#fcTopList .lostrow').length") == 3)
            pg.keyboard.press('Escape'); pg.wait_for_timeout(100)
            check(f'{tag}: Escape closes the top-3 dialog', not pg.is_visible('#fcTopBg'))
            ev(EMPTY); pg.wait_for_timeout(100)
            check(f'{tag}: without practice tests the card shows the question-bank model', pg.inner_text('#fcMiniVal') == f"{round(ev('forecast().mu')*100)}%")
            check(f'{tag}: empty strip says there are no tests', pg.inner_text('#tsLast') == '—' and 'No scored' in pg.inner_text('#tsSpark'))
            pg.evaluate(SETUP); pg.wait_for_timeout(150)

            # ---------- Practice tests tab ----------
            tap('#tsOpen'); pg.wait_for_timeout(300)
            check(f'{tag}: "Practice tests →" opens the Tests tab', pg.is_visible('#viewTests') and not pg.is_visible('#viewDash'))
            check(f'{tag}: address is #tests', ev('location.hash') == '#tests')
            kp = ev("[...document.querySelectorAll('#tsKpis b')].map(b=>b.textContent)")
            check(f'{tag}: 5 KPIs: last 78% / best 78% / avg 74% / 3 ≥ 70% / 0 ≥ 85%', kp == ['78%', '78%', '74%', '3', '0'], kp)
            tt = pg.inner_text('#tsTrendTxt')
            check(f'{tag}: trend shows +7.3 pp/week, R² 1.00 and the 85% date', '+7.3 pp/' in tt and 'R² 1.00' in tt and 'reaches 85%' in tt, tt)
            check(f'{tag}: chart has points, trend line, band and 70% / 85% lines', ev("document.querySelectorAll('#tsChart circle').length") == 5 and ev("document.querySelectorAll('#tsChart .s-reg,#tsChart .s-band,#tsChart .c70,#tsChart .c85').length") == 4)
            check(f'{tag}: the list shows 6 tests, the one in progress first', ev("document.querySelectorAll('#tsList .tsrow').length") == 6 and 'in progress' in pg.inner_text('#tsList .tsrow').lower(), pg.inner_text('#tsList')[:120])
            tap('#viewTests [data-tsr="7d"]'); pg.wait_for_timeout(200)
            check(f'{tag}: range 7D keeps 2 tests → "not enough data" for the trend', ev("document.querySelectorAll('#tsChart circle').length") == 2 and 'more scored' in pg.inner_text('#tsTrendTxt'), pg.inner_text('#tsTrendTxt'))
            tap('#viewTests [data-tsr="all"]'); pg.wait_for_timeout(150)
            # log a new test from the tab
            tap('#tsAdd'); pg.wait_for_timeout(200)
            check(f'{tag}: "+ Log practice test" opens the dialog with today', pg.is_visible('#ptbg') and pg.input_value('#ptDate') == ev('todayISO()'))
            pg.fill('#ptScore', '82'); tap('#ptSave'); pg.wait_for_timeout(250)
            check(f'{tag}: logging 82% adds it (always 60 questions)', ev("state.tests.filter(x=>x.score===82&&x.q===60).length") == 1 and pg.inner_text('#tsKpis b') == '82%')
            # edit
            rid = ev("state.tests.find(x=>x.score===82).id")
            tap(f'#tsList [data-edit="{rid}"]'); pg.wait_for_timeout(200)
            check(f'{tag}: Edit opens the dialog filled in', pg.is_visible('#ptbg') and pg.input_value('#ptScore') == '82')
            pg.fill('#ptScore', '84'); tap('#ptSave'); pg.wait_for_timeout(250)
            check(f'{tag}: editing changes the score without adding a test', ev("state.tests.filter(x=>x.score===84).length") == 1 and ev("state.tests.filter(x=>x.score===82).length") == 0 and ev('state.tests.length') == 7)
            tap(f'#tsList [data-edit="inprog"]'); pg.wait_for_timeout(200)
            pg.fill('#ptScore', '80'); tap('#ptSave'); pg.wait_for_timeout(250)
            check(f'{tag}: finishing the test in progress gives it a score', ev("state.tests.find(x=>x.id==='inprog').score") == 80)
            # delete + undo
            n = ev('state.tests.length')
            tap(f'#tsList [data-delpt="{rid}"]'); pg.wait_for_timeout(200)
            check(f'{tag}: delete removes the test', ev('state.tests.length') == n - 1)
            check(f'{tag}: delete offers undo', pg.is_visible('#toast'))
            check(f'{tag}: Tests page not wider than the screen', ev('document.documentElement.scrollWidth') == W)
            tap('#tsToStats'); pg.wait_for_timeout(300)
            check(f'{tag}: "Full statistics →" opens Statistics › Practice tests', pg.is_visible('#statTests') and not pg.is_visible('#statBank') and ev('location.hash') == '#stats-tests')

            # ---------- Statistics: Bank | Practice tests ----------
            check(f'{tag}: overall score panel explains the weights', 'weight' in pg.inner_text('#ovWeights') and ev("document.querySelectorAll('#ovKpis b').length") == 4)
            check(f'{tag}: trend chart drawn', ev("document.querySelectorAll('#tsChart2 .s-reg').length") == 1)
            check(f'{tag}: calibration scatter drawn with the perfect-model diagonal', ev("document.querySelectorAll('#calChart circle').length") == ev('scoredTests().length') and ev("document.querySelectorAll('#calChart .s-diag').length") == 1)
            check(f'{tag}: calibration text shows R² and bias', 'R²' in pg.inner_text('#calTxt') and 'predicted' in pg.inner_text('#calTxt'), pg.inner_text('#calTxt'))
            check(f'{tag}: score distribution has 5 buckets adding up to all tests', ev("[...document.querySelectorAll('#distBars .distrow span:last-child')].reduce((a,x)=>a+ +x.textContent,0)") == ev('scoredTests().length'))
            check(f'{tag}: interval between tests shown', 'days' in pg.inner_text('#gapTxt'))
            tap('#statSeg [data-stat="bank"]'); pg.wait_for_timeout(250)
            check(f'{tag}: "Question bank" shows forecast and spaced repetition again', pg.is_visible('#fcSection') and pg.is_visible('.srhero') and not pg.is_visible('#statTests'))
            tap('.tabs button[data-view="sr"]'); pg.wait_for_timeout(250)
            check(f'{tag}: Statistics tab opens on the question bank', pg.is_visible('#statBank'))
            check(f'{tag}: Statistics page not wider than the screen', ev('document.documentElement.scrollWidth') == W)

            # ---------- plan: cadence ----------
            ev("state.tests=[{id:'a',date:addDays(todayISO(),-3),q:60,score:75}];state.settings.testEvery=3;save();render()")
            check(f'{tag}: test every 3 days, last one 3 days ago → test in today\'s plan', ev("buildPlan().items.some(x=>x.kind==='test'&&x.n===60)"))
            tap('.tabs button[data-view="plan"]'); pg.wait_for_timeout(250)
            check(f'{tag}: Plan setting reads "every N days" and shows 3', 'every' in pg.inner_text('#viewPlan').lower() and pg.input_value('#setTests') == '3')
            pg.fill('#setTests', '7'); pg.press('#setTests', 'Enter'); pg.wait_for_timeout(700)
            check(f'{tag}: every 7 days → no test today', ev('settings().testEvery') == 7 and not ev("buildPlan().items.some(x=>x.kind==='test')"))
            pg.reload(); pg.wait_for_timeout(400)
            check(f'{tag}: the setting survives a reload', ev('settings().testEvery') == 7)
            ev("state.settings.testEvery=3;save();render()")
            check(f'{tag}: the setting goes into the backup', ev('JSON.parse(JSON.stringify(state)).settings.testEvery') == 3 and ev("normalize(JSON.parse(JSON.stringify(state))).settings.testEvery") == 3)

            # ---------- languages ----------
            pg.click('.flag[data-lang="pt"]'); pg.wait_for_timeout(150)
            check(f'{tag}: Portuguese tab "Simulados"', pg.inner_text('.tabs button[data-view="tests"]') == 'Simulados')
            pg.click('.flag[data-lang="ja"]'); pg.wait_for_timeout(150)
            check(f'{tag}: Japanese tab "模試"', pg.inner_text('.tabs button[data-view="tests"]') == '模試')
            pg.click('.flag[data-lang="en"]')
            check(f'{tag}: no JavaScript errors', not errs, errs)
            c.close()

    # ---------- demo data ----------
    c = b.new_context(viewport={'width': 1440, 'height': 900}); pg = c.new_page()
    pg.goto('file://' + os.path.join(ROOT, 'demo.html')); pg.wait_for_timeout(450)
    n = pg.evaluate('scoredTests().length')
    check('demo: 8–9 fictional practice tests', 8 <= n <= 9, n)
    check('demo: enough tests for trend and calibration', pg.evaluate('testTrend("all").reg!==null') and pg.evaluate('calibration().pts.length>=5'))
    c.close(); b.close()

ok = sum(r[1] for r in results)
print(f'\n{ok}/{len(results)} practice-test tests passed\n')
for n, g, d in results: print(('PASS ' if g else 'FAIL ') + n + ('' if g else f'\n      → {d}'))
sys.exit(0 if ok == len(results) else 1)
