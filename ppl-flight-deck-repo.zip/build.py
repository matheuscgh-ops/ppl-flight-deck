"""Build index.html (personal) and demo.html (fictional data) from the single source src/app.html.

The demo differs from the personal app only in: title, DEMO tag, storage key, the example data
(src/demo_state.js), disabled cloud sync and the guided tour (src/demo_tour.html). Every replacement must match exactly once.
Usage: python3 build.py"""
import os
ROOT = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(ROOT, 'src', 'app.html'), encoding='utf-8').read()
demo_state = open(os.path.join(ROOT, 'src', 'demo_state.js'), encoding='utf-8').read()
demo_tour = open(os.path.join(ROOT, 'src', 'demo_tour.html'), encoding='utf-8').read()

DEMO = [
    ('<title>PPL Flight Deck</title>', '<title>PPL Flight Deck — Demo</title>'),
    ('</style>', '.demotag{font-style:normal;font-size:.45em;vertical-align:middle;letter-spacing:.08em;color:#ffd08a;background:#3d2b14;border:1px solid #6b4a1c;border-radius:6px;padding:2px 7px;margin-left:6px}\n#syncChip{display:none!important}\n</style>'),
    ('<div class="brand">PPL <span>/</span> FLIGHT DECK</div>', '<div class="brand">PPL <span>/</span> FLIGHT DECK <em class="demotag">DEMO</em></div>'),
    ("const STORE='ppl-flight-deck-v13';", "const STORE='ppl-flight-deck-demo'; /* DEMO: separate storage — never touches the personal app */"),
    ('function defaultState(){return realState()}', demo_state + 'function defaultState(){return demoState()}'),
    ("let sync=(()=>{try{return JSON.parse(localStorage.getItem(SYNC_KEY))||{}}catch(e){return {}}})();", "let sync={}; /* DEMO: sync disabled */"),
    ("function syncStore(){try{", "function syncStore(){return;try{"),
    # guided tour: a header button + the tour script (src/demo_tour.html)
    ('<button id="clearDemo" data-t="clear"></button>', '<button id="clearDemo" data-t="clear"></button>\n      <button id="tourBtn" type="button">? Tour</button>'),
    ('</body>', demo_tour + '</body>'),
]

def build_demo(s):
    for a, b in DEMO:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f'build: expected 1 match, found {n}: {a[:70]}')
        s = s.replace(a, b)
    return s

if __name__ == '__main__':
    open(os.path.join(ROOT, 'index.html'), 'w', encoding='utf-8').write(src)
    open(os.path.join(ROOT, 'demo.html'), 'w', encoding='utf-8').write(build_demo(src))
    print('built index.html and demo.html from src/app.html')
